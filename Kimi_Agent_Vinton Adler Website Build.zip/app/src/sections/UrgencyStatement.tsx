import ScrollReveal from '../components/ScrollReveal';

export default function UrgencyStatement() {
  return (
    <section className="bg-card border-t border-[#262626]">
      <div className="max-w-[800px] mx-auto px-6 text-center py-16 md:py-20">
        <ScrollReveal>
          <p className="text-lg md:text-xl text-[#F5F0E8] leading-relaxed font-medium">
            Every day without a structured pipeline, a portion of your inbound demand goes to competitors who respond faster and follow up better.
          </p>
          <p className="text-lg md:text-xl text-[#F5F0E8] leading-relaxed font-medium mt-4">
            That loss is not visible in your ad spend. It shows up as quiet months, thinner margins, and the sense that your marketing should be producing more.
          </p>
          <p className="text-base text-primary mt-6 font-semibold">
            We limit each market to 2 to 3 clients so we can deliver focused attention and consistent results.
          </p>
        </ScrollReveal>
      </div>
    </section>
  );
}
