import { Zap, Shield, Clock, TrendingUp } from 'lucide-react';
import ScrollReveal from '../components/ScrollReveal';

const badges = [
  { icon: Zap, label: 'ONE-TIME INSTALL' },
  { icon: Shield, label: 'NO RETAINER REQUIRED' },
  { icon: Clock, label: '30-60 DAY DEPLOYMENT' },
  { icon: TrendingUp, label: 'PROVEN FRAMEWORK' },
];

export default function WhyChoose() {
  return (
    <section className="bg-[#F5F0E8] border-y border-[#E5E0D8]">
      <div className="max-w-[1000px] mx-auto px-6 py-16 md:py-20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {badges.map((b, i) => {
            const Icon = b.icon;
            return (
              <ScrollReveal key={i} delay={i * 0.06}>
                <div className="bg-white border border-[#E5E0D8] rounded-xl p-6 text-center">
                  <Icon className="w-5 h-5 text-[#C9A962] mx-auto mb-3" />
                  <p className="text-xs font-bold uppercase tracking-[0.06em] text-[#0A0A0A]">{b.label}</p>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
