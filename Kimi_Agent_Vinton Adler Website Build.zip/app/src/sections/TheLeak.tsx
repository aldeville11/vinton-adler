import { PhoneMissed, MailOpen, MapPin } from 'lucide-react';
import SectionLabel from '../components/SectionLabel';
import ScrollReveal from '../components/ScrollReveal';

const leakItems = [
  {
    icon: PhoneMissed,
    title: 'Lead Capture Gaps',
    text: 'When an inquiry comes in and no one responds fast enough, that buyer moves to the next option. You paid for the click. Someone else gets the job.',
  },
  {
    icon: MailOpen,
    title: 'Follow-Up Gaps',
    text: 'One touch is not enough for most buyers. Without structured continuation, interest fades and the prospect becomes someone else\u2019s customer.',
  },
  {
    icon: MapPin,
    title: 'Visibility Gaps',
    text: 'If you are not showing up where high-intent buyers search, they never see you at the moment they are ready to decide.',
  },
];

export default function TheLeak() {
  return (
    <section id="the-leak" className="bg-background border-t border-[#1C1C1C]">
      <div className="max-w-[800px] mx-auto px-6 md:px-12 lg:px-20 py-20 md:py-28 lg:py-32">
        <ScrollReveal className="text-center mb-12">
          <SectionLabel text="WHERE REVENUE IS LOST" />
          <h2 className="text-[clamp(32px,4vw,48px)] font-semibold text-[#F5F0E8] leading-[1.2] tracking-[-0.01em]">
            The gap between inquiry and booked appointment is where income disappears.
          </h2>
          <p className="text-lg text-[#A8A29E] mt-6 leading-relaxed">
            Most of this loss is invisible. It does not show up in your marketing dashboard. It shows up as a lighter schedule, slower months, and competitors who seem to close more easily.
          </p>
        </ScrollReveal>

        <div className="space-y-0">
          {leakItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <div key={index} className="py-5 border-b border-[#262626]">
                <div className="flex items-start gap-4">
                  <Icon className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-base font-semibold text-[#F5F0E8]">{item.title}</p>
                    <p className="text-[15px] text-[#A8A29E] mt-1 leading-relaxed">{item.text}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <p className="text-base text-primary font-semibold mt-8 text-center">
          We find the highest-impact gaps, fix them in order, and improve your close rate from the demand you already have.
        </p>
      </div>
    </section>
  );
}
